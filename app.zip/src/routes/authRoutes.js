const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

// Render the login page (GET /auth/login)
router.get("/login", (req, res) => {
  res.render("login"); // Render the login.ejs file
});

// Handle login form submission (POST /auth/login)
router.post("/login", authController.login);

// Account Route
router.get("/account", (req, res) => {
  if (req.session.isLoggedIn) {
    // Replace the user details with actual session or database data
    const userDetails = {
      username: req.session.username || "JohnDoe",
      mobile: req.session.mobile || "123-456-7890",
    };

    res.send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Account</title>
      </head>
      <body>
        <h1>Account Details</h1>
        <p><strong>Username:</strong> ${userDetails.username}</p>
        <p><strong>Mobile Number:</strong> ${userDetails.mobile}</p>
        <nav>
          <a href="/dashboard">Back to Dashboard</a> |
          <form action="/auth/logout" method="POST" style="display:inline;">
            <button type="submit">Logout</button>
          </form>
        </nav>
      </body>
      </html>
    `);
  } else {
    res.redirect("/auth/login"); // Redirect to login if the user is not logged in
  }
});

// Logout Route
router.post("/logout", authController.logout);

module.exports = router;