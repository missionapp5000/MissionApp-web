const source1Scraper = require("./source1Scraper");

// Add more sources if needed
module.exports = {
  source1: source1Scraper,
};